select	distinct e.fname, e.minit, e.lname, e.address
from	employee e
inner join works_on w on w.essn = e.ssn
inner join project p on p.pnumber = w.pno
where 	p.plocation = 'Houston'
and		not exists
(
	select	*
	from	dept_locations dl
	where 	dl.dnumber = e.dno
    and		dl.dlocation = p.plocation
)
order by e.fname
