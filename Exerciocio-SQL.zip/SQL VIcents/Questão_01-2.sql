select e.fname, e.minit, e.lname from employee e
inner join dependent d on d.essn = e.ssn
where e.fname = d.dependent_name
