select	c.cname
from	customers c
inner	join orders o		on o.cno = c.cno
inner	join employees e	on e.eno = o.eno
inner	join zipcodes z 	on z.zip = e.zip
where	z.city = 'Wichita'
and		not exists
(
	select	*
	from	orders o1
	inner	join employees e1	on e1.eno = o1.eno
	inner	join zipcodes z1	on z1.zip = e1.zip
	where	z1.city != 'Wichita'
	and		o1.cno = o.cno
)
    