select fname, minit, lname
from
(
	select e.fname, e.minit, e.lname, count(*) as projetos from employee e
	inner join works_on w on w.essn = e.ssn
	group by e.fname, e.minit, e.lname
	having count(*) = (select count(*) from project)
) filtro
