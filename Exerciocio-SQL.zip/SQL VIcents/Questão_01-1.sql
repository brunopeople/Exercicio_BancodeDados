select e.fname, e.minit, e.fname from employee e
inner join works_on w on e.ssn = w.essn
inner join project p on p.pnumber = w.pno
where hours > 10 and p.pname = 'ProductX'

