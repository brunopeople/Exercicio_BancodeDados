select	p.pjname
from	sppj
inner join 	projects p 	on p.pjno = sppj.projects_pjno
where	sppj.suppliers_sno = 'S1'
group by p.pjname
having count(*) = 1