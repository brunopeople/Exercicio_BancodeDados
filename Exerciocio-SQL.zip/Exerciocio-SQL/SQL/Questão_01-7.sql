select e.fname, e.minit, e.lname from employee e
inner join department d on d.mgr_ssn = e.ssn
where not exists
(
	select	*
    from	dependent dp
    where	dp.essn = d.mgr_ssn
);
