select	c.cname
from	orders o
inner join odetails od	on od.ono = o.ono
inner join customers c 	on c.cno = o.cno
inner join parts p on p.pno = od.pno
where	p.price < 20.00
group by c.cname
having	count(distinct od.pno) = 
(
	select	count(*)
	from 	parts p
	where	p.price < 20.00
)