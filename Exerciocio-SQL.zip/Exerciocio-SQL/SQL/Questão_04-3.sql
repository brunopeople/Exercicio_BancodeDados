select	p.pname
from	sppj
inner join 	parts p 	on p.pno = sppj.parts_pno
inner join 	suppliers s	on s.sno = sppj.suppliers_sno
group by p.pname
having count( distinct s.sname) =
(
	select	count(*)
	from	suppliers
)