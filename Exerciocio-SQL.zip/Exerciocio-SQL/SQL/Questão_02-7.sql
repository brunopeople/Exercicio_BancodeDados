select	c.cname
from	orders o
inner join customers c 	on c.cno = o.cno
group by c.cname
having count(*) = 2
