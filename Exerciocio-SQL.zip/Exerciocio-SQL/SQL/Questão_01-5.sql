select e.fname, e.minit, e.lname from employee e
where not exists
(select * from works_on w where w.essn = e.ssn)