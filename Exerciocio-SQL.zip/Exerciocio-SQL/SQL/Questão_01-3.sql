select subordinado.fname, subordinado.minit, subordinado.lname from employee subordinado
inner join employee chefe on subordinado.super_ssn = chefe.ssn
where chefe.fname = 'Franklin' and chefe.lname = 'Wong'
