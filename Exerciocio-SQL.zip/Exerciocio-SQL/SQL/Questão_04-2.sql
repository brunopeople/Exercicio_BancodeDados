select	sname
from	sppj
inner join 	suppliers s	on s.sno = sppj.suppliers_sno
where sppj.projects_pjno = 'J1'
group by 	sname
having count(distinct sppj.parts_pno) > 2