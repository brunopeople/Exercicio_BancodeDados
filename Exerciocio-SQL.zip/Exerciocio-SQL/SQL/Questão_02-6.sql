select	c.cname
from	customers c
where	not exists
(
	select	*
    from	orders o
    where	o.cno = c.cno
)