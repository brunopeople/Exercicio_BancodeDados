select	pname
from	sppj
inner join 	parts p on p.pno = parts_pno
group by 	pname
having count(distinct projects_pjno) = 2