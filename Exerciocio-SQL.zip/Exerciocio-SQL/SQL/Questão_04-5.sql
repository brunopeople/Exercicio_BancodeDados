select	sname
from 	suppliers s
where	s.sno in
(
	select	a.suppliers_sno
	from
	(
		select	suppliers_sno, projects_pjno, count(*) as pecas
		from	sppj A
		group by suppliers_sno,projects_pjno
		having 	count(*) > 1
	) a
	group by a.suppliers_sno
	having count(*) > 1
)