select	e.ename, z.city
from	employees e
inner	join zipcodes z		on z.zip = e.zip
inner	join
(
	select	o.eno , sum(p.price * od.qty)
	from	orders o
	inner 	join odetails od	on od.ono = o.ono
	inner	join parts p		on p.pno = od.pno
	group by o.eno
	having 	sum(p.price * od.qty) > 50.00
) vendas on vendas.eno = e.eno;