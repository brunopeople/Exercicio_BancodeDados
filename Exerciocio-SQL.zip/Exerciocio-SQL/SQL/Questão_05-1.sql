select	distinct s.name
from	students s
inner join enrolls er	on er.students_ssn	= s.ssn
inner join courses c 	on c.cnum			= er.courses_cnum
inner join bookuses bu	on bu.courses_cnum	= c.cnum
inner join books b 		on b.isbn			= bu.books_isbn
where 	b.publisher = 'Addison Wesley'