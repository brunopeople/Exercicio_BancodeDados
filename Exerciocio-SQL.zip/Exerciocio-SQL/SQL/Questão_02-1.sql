select	pname
from	parts p
where	price < 20